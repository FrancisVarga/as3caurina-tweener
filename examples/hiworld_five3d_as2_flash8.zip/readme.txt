PLEASE NOTICE!

This source file is one of FIVe3D's own examples, created by Mathieu Badimon.
I don't claim ownership over it, as I only adapted it to use Tweener when moving.
The same goes for FIVe3D's classes; they're used here to make the code compilable,
but I didn't write them.

This example works as a way to show how Tweener can be integrated with the FIVe3D extension.
However, I advise anyone interested to get the real FIVe3D classes and examples from the official website:

http://five3d.mathieu-badimon.com/



- Zeh
