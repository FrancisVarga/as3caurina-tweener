PLEASE NOTICE! This example won't run unless you also have the PaperVision3D classes installed and working. It doesn't come with the PaperVision source!

More information here:

http://osflash.org/papervision3d
http://www.papervision3d.org/
http://blog.papervision3d.org/
